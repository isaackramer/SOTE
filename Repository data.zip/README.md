This repository contains supplementary information related to the article:


The following materials are available:

1. Validation raw data (validation_data.zip): contains the raw output from SOTE, as well as the measured data and Hydrus results to which SOTE was compared. We note that he measured and Hydrus results were collected by Gonçalves et. al. (2006) and are included here with permission of the author. A detailed description of the method used for comparing the measured and modeled results is obtained in our manuscript. We note here, however, that the Hydrus and measured data include results at two soil depths (10 cm and 30 cm), because we used a lumped result in our validation. File overview:
   * Soil Water Content
     - swc_SOTE.csv: This CSV contains SOTE output for soil water content. Units: $s$ ($\theta/n$).
      - swc_HYDRUS.csv: This CSV contains Hydrus output for soil water content. Units: $\theta$. Note the hydrus simulations included only one set of data for all three lysimeters.
      - swc_measured.csv: This CSV contains measured data for soil water content. Units:  $100*\theta$.
    * Salinity Concentration
       - salinity_SOTE.csv: This CSV contains SOTE output for salinity. Units: $C_s$ (mmol$_c$/L).
       - salinity_HYDRUS.csv: This CSV contains HYDRUS output for salinity. Units: $C_s$ (dS/m).
       - salinity_measured.csv: This CSV contains measured data for salinity. Units: $C_s$ (dS/m).
    * Sodicity Fraction
      - sodicity_SOTE.csv: This CSV contains SOTE output for sodicity. Units: ESP/100.
      - sodicity_HYDRUS.csv: This CSV contains SOTE output for sodicity. Units: ESP.
      - sodicity_measured.csv: This CSV contains measured output for sodicity. Units: ESP.


Gonçalves, M.C., Šimůnek, J., Ramos, T.B., Martins, J.C., Neves, M.J., Pires, F.P., 2006. Multicomponent solute transport in soil lysimeters irrigated with waters of different quality. Water Resour. Res. 42, 1–17. https://doi.org/10.1029/2005WR004802
